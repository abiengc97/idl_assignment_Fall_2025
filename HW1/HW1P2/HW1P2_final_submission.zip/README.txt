- **Model**: Model archtiecture description. Anything unique? Any specific architecture shapes or strategies?pyramid after trying different architecture and I made the layers such that the number of paramters are 19.95 Million
- **Training Strategy**: optimizer + scheduler + loss function + any other unique ideas: retrained with checkpoint model_96.pth from(https://wandb.ai/agcheria-carnegie-mellon-university/hw1p2/runs/jsoj5nll?nw=nwuseragcheria) with lower lr (0.0005) 
- **Augmentations**: augmentations if used. If augmentations weren't used, then ignore: both are used with lower probability for augmentation
- **Notebook Execution**: Any instructions required to run your notebook.
final wandb:https://wandb.ai/agcheria-carnegie-mellon-university/hw1p2/runs/w0zpsvte?nw=nwuseragcheria
