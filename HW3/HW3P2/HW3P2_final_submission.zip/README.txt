-# Architecture and Implementation Guide

## Overview

This project implements an end-to-end Automatic Speech Recognition (ASR) system for phoneme recognition using a hybrid architecture that combines EfficientNet-style convolutional blocks with Pyramidal Bidirectional LSTM (pBLSTM) layers. The system processes MFCC (Mel-Frequency Cepstral Coefficients) features and predicts phoneme sequences using Connectionist Temporal Classification (CTC) loss.

## Architecture Design Philosophy

The architecture follows an **Encoder-Decoder** paradigm optimized for sequence-to-sequence phoneme recognition:

1. **Encoder**: Extracts hierarchical features from audio using convolutional blocks, then models temporal dependencies with pyramidal BiLSTM
2. **Decoder**: Maps encoded features to phoneme log-probabilities using a multi-layer perceptron
3. **CTC Loss**: Handles alignment between variable-length audio sequences and phoneme sequences

## Architecture Components

### 1. EfficientBlock1D: EfficientNet-Style Convolutional Block

**Location**: Lines 497-545

**Purpose**: Implements a depthwise separable convolution block inspired by EfficientNet, optimized for 1D audio sequences.

**Architecture**:
```
Input → Expansion Conv (1x1) → Depthwise Conv (5x1) → Projection Conv (1x1) → Output
         ↓                        ↓                        ↓
      BatchNorm               BatchNorm               BatchNorm
         ↓                        ↓                        ↓
       SiLU                     SiLU                     
         ↓                        ↓
    (Expand 4x)            (Spatial Conv)         (Project to output)
```

**Key Features**:
- **Expansion Phase**: Expands channels by a factor of 4 (expand_ratio=4) using 1x1 convolution
- **Depthwise Convolution**: Applies spatial convolution with kernel_size=5, using grouped convolution for efficiency
- **Projection Phase**: Reduces channels back to desired output size using 1x1 convolution
- **Residual Connection**: Adds skip connection when stride=1 and input_channels == output_channels
- **SiLU Activation**: Uses Swish activation (SiLU) which has shown better performance than ReLU for audio tasks

**Why This Design?**:
- **Parameter Efficiency**: Depthwise separable convolution reduces parameters while maintaining representational power
- **Better Feature Extraction**: The expansion-projection pattern allows the network to learn richer feature representations
- **Residual Learning**: Skip connections enable gradient flow and help with training deeper networks

**Implementation Details**:
```python
# Expansion: in_channels → in_channels * 4
expand_conv: Conv1d(in_channels, hidden_dim, kernel_size=1)

# Depthwise: hidden_dim → hidden_dim (spatial convolution)
depthwise_conv: Conv1d(hidden_dim, hidden_dim, kernel_size=5, groups=hidden_dim)

# Projection: hidden_dim → out_channels
project_conv: Conv1d(hidden_dim, out_channels, kernel_size=1)
```

### 2. Encoder: Hierarchical Feature Extraction

**Location**: Lines 547-614

**Purpose**: Transforms raw MFCC features into rich, temporally-aware representations suitable for phoneme prediction.

**Architecture Flow**:
```
MFCC Input (B, T, 28)
    ↓
Transpose to (B, 28, T) for Conv1d
    ↓
Initial Conv1d (stride=2, kernel=15) → 64 channels
    ↓
BatchNorm + SiLU
    ↓
EfficientBlock1D: 64 → 128 channels
    ↓
EfficientBlock1D: 128 → 256 channels
    ↓
EfficientBlock1D: 256 → 256 channels (x2)
    ↓
Transpose back to (B, T', 256)
    ↓
pBLSTM (256 → 512 hidden, bidirectional)
    ↓
LockedDropout
    ↓
Output (B, T'', 512)
```

**Components**:

#### 2.1 Embedding Layer (Convolutional Feature Extraction)
- **Initial Convolution**: 
  - Input: 28 MFCC features
  - Output: 64 channels
  - Kernel size: 15 (captures local temporal patterns)
  - Stride: 2 (reduces sequence length by half)
  
- **EfficientNet Blocks**:
  - Block 1: 64 → 128 channels
  - Block 2: 128 → 256 channels  
  - Block 3: 256 → 256 channels (maintains dimension)
  - Block 4: 256 → 256 channels (deepens representation)
  
- **Why This Progression?**
  - Gradually increases feature dimensionality
  - Maintains 256 channels in deeper layers to avoid over-parameterization
  - Each block learns increasingly abstract features

#### 2.2 Pyramidal Bidirectional LSTM (pBLSTM)
- **Purpose**: Models long-range temporal dependencies while reducing sequence length
- **Architecture**: 3-layer bidirectional LSTM with hidden_size=512
- **Downsampling**: Each pBLSTM layer halves the sequence length by concatenating adjacent timesteps
- **Output**: 512-dimensional features (256 forward + 256 backward)

**How pBLSTM Works**:
1. Unpacks padded sequence
2. Concatenates adjacent timesteps: `[t1, t2] → [t1||t2]` (reduces T by 2x, doubles features)
3. Packs sequence for efficient LSTM processing
4. Processes through bidirectional LSTM
5. Returns packed output

**Why pBLSTM?**:
- **Computational Efficiency**: Reduces sequence length progressively, making training faster
- **Better Context**: Bidirectional processing captures both past and future context
- **Information Preservation**: Concatenation maintains information density despite downsampling

#### 2.3 LockedDropout
- **Purpose**: Applies consistent dropout mask across all timesteps (variational dropout)
- **Why Locked?**: Standard dropout varies across timesteps, which is problematic for RNNs. Locked dropout maintains temporal consistency.

### 3. Decoder: Phoneme Classification

**Location**: Lines 617-642

**Purpose**: Maps encoded features to phoneme log-probabilities for each timestep.

**Architecture**:
```
Encoder Output (B, T, 512)
    ↓
BatchNorm (with permutation for compatibility)
    ↓
Linear: 512 → 128
    ↓
GELU activation
    ↓
Linear: 128 → 64
    ↓
GELU activation
    ↓
Linear: 64 → 41 (number of phonemes)
    ↓
LogSoftmax
    ↓
Output (B, T, 41) - log probabilities
```

**Design Choices**:
- **Progressive Dimension Reduction**: 512 → 128 → 64 → 41 gradually reduces features
- **GELU Activation**: Gaussian Error Linear Unit provides smooth gradients
- **LogSoftmax**: Outputs log-probabilities for numerical stability with CTC loss

### 4. ASRModel: Complete Pipeline

**Location**: Lines 644-677

**Purpose**: Combines all components with data augmentation.

**Forward Pass**:
```
Input (B, T, 28)
    ↓
[Training Only] Data Augmentation:
    - Time Masking (mask_param=30)
    - Frequency Masking (mask_param=30)
    ↓
Encoder:
    - Convolutional feature extraction
    - pBLSTM temporal modeling
    ↓
Decoder:
    - Phoneme classification
    ↓
Output: (B, T', 41) log-probabilities
```

**Data Augmentation**:
- **Time Masking**: Randomly masks consecutive timesteps (simulates speech rate variations)
- **Frequency Masking**: Randomly masks MFCC coefficients (simulates channel noise)
- **Why Only in Training?**: Augmentation helps generalization but shouldn't be applied during inference

## How We Implemented It

### Step 1: Data Preprocessing

**AudioDataset Class** (Lines 97-218):
1. **Loading**: Loads MFCC features and phoneme transcripts from `.npy` files
2. **Normalization**: Per-sample mean/std normalization: `(mfcc - mean) / (std + 1e-8)`
3. **Mapping**: Converts phoneme strings to integer indices for CTC loss
4. **Padding**: Custom collate function pads sequences to same length for batching

**Key Design**:
- Normalization happens per-sample (not global) to handle varying audio characteristics
- Padding is done in collate function for efficiency

### Step 2: Model Architecture Design

**Design Process**:
1. **Started with Basic Architecture**: Simple Conv1d + LSTM + Linear
2. **Improved Feature Extraction**: Replaced simple conv with EfficientNet-style blocks
3. **Added Temporal Modeling**: Integrated pBLSTM for better sequence understanding
4. **Optimized Parameters**: Tuned channel dimensions to stay under 20M parameter limit

**Parameter Budget**:
- Target: < 20 million parameters
- Strategy: Used depthwise separable convolutions, limited LSTM layers, efficient channel dimensions

### Step 3: Training Strategy

**Loss Function**: CTC Loss
- Handles variable-length sequences without explicit alignment
- Uses blank token for alignment flexibility
- `zero_infinity=True` for numerical stability

**Optimizer**: AdamW
- Learning rate: 1e-4
- Weight decay: 1e-2 (L2 regularization)
- Betas: (0.9, 0.98)

**Learning Rate Schedule**: OneCycleLR
- Warmup: 15% of training
- Cosine annealing
- Initial LR: max_lr / 25
- Final LR: max_lr / 10000

**Training Techniques**:
- **Mixed Precision (FP16)**: Faster training, lower memory
- **Gradient Clipping**: Prevents exploding gradients (max_norm=5.0)
- **Progressive Augmentation**: Started with light augmentation, increased during training

### Step 4: Decoding Strategy

**CTC Decoder**: CUDA CTC Decoder with beam search
- **Training**: Beam width = 6, blank_skip_threshold = 0.90
- **Testing**: Beam width = 6, blank_skip_threshold = 0.75 (more thorough search)

**Why Beam Search?**:
- Explores multiple hypotheses simultaneously
- Better than greedy decoding for sequence tasks
- Balances quality and computational cost

### Step 5: Evaluation

**Metrics**:
- **CTC Loss**: Training objective
- **Levenshtein Distance**: Edit distance between predicted and ground truth phoneme sequences
  - Lower is better
  - Measures actual prediction quality

**Validation Strategy**:
- Monitor validation Levenshtein distance
- Save best model based on validation performance
- Checkpoint both best and last epoch models

## Key Design Decisions

### 1. Why EfficientNet-Style Blocks?

**Problem**: Need efficient feature extraction without exceeding parameter budget.

**Solution**: Depthwise separable convolution reduces parameters by ~8x compared to standard convolution while maintaining representational power.

**Result**: Rich feature representations with fewer parameters.

### 2. Why pBLSTM Instead of Standard LSTM?

**Problem**: Long audio sequences are computationally expensive with standard LSTM.

**Solution**: Pyramidal structure progressively reduces sequence length while maintaining information through concatenation.

**Result**: Faster training, better long-range dependencies, maintained accuracy.

### 3. Why SiLU/GELU Instead of ReLU?

**Problem**: ReLU can cause dead neurons and has sharp gradients.

**Solution**: 
- **SiLU (Swish)**: Smooth, non-monotonic activation that has shown better performance for audio
- **GELU**: Gaussian-based activation with smooth gradients

**Result**: Better gradient flow, improved training stability.

### 4. Why LockedDropout Instead of Standard Dropout?

**Problem**: Standard dropout varies across timesteps in RNNs, breaking temporal consistency.

**Solution**: Locked dropout applies the same mask across all timesteps, maintaining temporal structure.

**Result**: Better regularization for recurrent layers.

### 5. Why Progressive Augmentation?

**Problem**: Strong augmentation from the start can hurt learning.

**Solution**: Start with light augmentation (mask_param=10), then increase (mask_param=30) after initial convergence.

**Result**: Better convergence, improved generalization.

## Architecture Summary

```
Input: MFCC Features (B, T, 28)
    ↓
[Augmentation: Time + Frequency Masking] (Training Only)
    ↓
Encoder:
    Conv1d (28→64, stride=2, kernel=15)
    EfficientBlock1D (64→128)
    EfficientBlock1D (128→256)
    EfficientBlock1D (256→256) × 2
    pBLSTM (256→512, bidirectional)
    LockedDropout
    ↓
Decoder:
    BatchNorm
    Linear (512→128) + GELU
    Linear (128→64) + GELU
    Linear (64→41) + LogSoftmax
    ↓
Output: Phoneme Log-Probabilities (B, T', 41)
```

## Training Pipeline

1. **Data Loading**: Custom datasets with per-sample normalization
2. **Forward Pass**: MFCC → Encoder → Decoder → Log-probabilities
3. **Loss Calculation**: CTC loss between predictions and ground truth
4. **Backward Pass**: Mixed precision training with gradient clipping
5. **Optimization**: AdamW with OneCycleLR scheduling
6. **Validation**: Compute CTC loss and Levenshtein distance
7. **Checkpointing**: Save best model based on validation Levenshtein distance

## Results and Performance

- **Model Size**: < 20 million parameters (within constraint)
- **Training**: Stable convergence with progressive augmentation
- **Evaluation**: Levenshtein distance on validation set
- **Inference**: Beam search decoding with CUDA CTC decoder

## Key Takeaways

1. **Efficient Architecture**: EfficientNet-style blocks provide rich features with fewer parameters
2. **Temporal Modeling**: pBLSTM efficiently handles long sequences while maintaining context
3. **Training Strategy**: Progressive augmentation and careful learning rate scheduling improve convergence
4. **CTC Alignment**: Handles variable-length sequences without explicit alignment
5. **Beam Search**: Better decoding quality than greedy approaches

This architecture successfully balances model capacity, computational efficiency, and prediction accuracy for phoneme recognition tasks.


Training:
Intial the scheduler used is OneCycleLR with a max learning rate of 0.001.
Then scheduler PlateauLR was used to reduce the learning rate when the validation Dist stopped improving.
run1:https://wandb.ai/agcheria-carnegie-mellon-university/hw3p2-ablations/runs/661u6zy5?nw=nwuseragcheria
run2:https://wandb.ai/agcheria-carnegie-mellon-university/hw3p2-ablations/runs/katoccvp?nw=nwuseragcheria